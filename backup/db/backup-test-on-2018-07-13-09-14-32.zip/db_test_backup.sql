#
# TABLE STRUCTURE FOR: todo
#

DROP TABLE IF EXISTS `todo`;

CREATE TABLE `todo` (
  `tgl` datetime NOT NULL,
  `activity` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-07 07:26:35', 'Melakukan Backup untuk waktu 2018-06-07 07:26:35 ', 'Sukses', 'Tidak ada');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-07 11:25:18', 'Melakukan backup untuk waktu 2018-06-07 11:25:18', 'Sukses', 'Tidak ada');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-07 12:35:00', 'Melakukan backup 2018-06-07 12:35:00 ', 'Sukses', 'Tidak ada');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-07 12:41:13', 'Melakukan backup 2018-06-07 12:41:13', 'Sukses', 'Tidak ada');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `user` (`username`, `password`) VALUES ('ayam', 'ayam');
INSERT INTO `user` (`username`, `password`) VALUES ('domba', 'domba');
INSERT INTO `user` (`username`, `password`) VALUES ('kera', 'kera');
INSERT INTO `user` (`username`, `password`) VALUES ('monyet', 'monyet');


