#
# TABLE STRUCTURE FOR: list_database
#

DROP TABLE IF EXISTS `list_database`;

CREATE TABLE `list_database` (
  `id_db` int(255) NOT NULL AUTO_INCREMENT,
  `hostname` varchar(15) NOT NULL,
  `username` varchar(50) NOT NULL,
  `name_database` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `port` varchar(4) NOT NULL,
  PRIMARY KEY (`id_db`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `list_database` (`id_db`, `hostname`, `username`, `name_database`, `password`, `port`) VALUES (1, 'localhost', 'root', 'ci_magang', '', '3306');
INSERT INTO `list_database` (`id_db`, `hostname`, `username`, `name_database`, `password`, `port`) VALUES (6, 'localhost', 'root', 'test', 'hehe', '3306');
INSERT INTO `list_database` (`id_db`, `hostname`, `username`, `name_database`, `password`, `port`) VALUES (8, '10.60.180.28', 'bck_test', 'bck_db_test', 'Test123', '3306');
INSERT INTO `list_database` (`id_db`, `hostname`, `username`, `name_database`, `password`, `port`) VALUES (9, 'localhost', 'root', 'test2', '', '3306');


#
# TABLE STRUCTURE FOR: list_file
#

DROP TABLE IF EXISTS `list_file`;

CREATE TABLE `list_file` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `tgl` datetime NOT NULL,
  `filename` varchar(255) NOT NULL,
  `mime` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=latin1;

INSERT INTO `list_file` (`id`, `tgl`, `filename`, `mime`) VALUES (114, '2018-08-02 11:00:58', 'backup-test-on-2018-08-02-11-00-58.zip', 'application/x-zip');
INSERT INTO `list_file` (`id`, `tgl`, `filename`, `mime`) VALUES (115, '2018-08-03 11:30:43', 'backup-test-on-2018-08-03-11-30-43.zip', 'application/x-zip');
INSERT INTO `list_file` (`id`, `tgl`, `filename`, `mime`) VALUES (116, '2018-08-03 11:30:43', 'backup-test2-on-2018-08-03-11-30-43.zip', 'application/x-zip');
INSERT INTO `list_file` (`id`, `tgl`, `filename`, `mime`) VALUES (117, '2018-08-03 11:39:48', 'backup-test-on-2018-08-03-11-39-48.zip', 'application/x-zip');
INSERT INTO `list_file` (`id`, `tgl`, `filename`, `mime`) VALUES (118, '2018-08-03 11:39:48', 'backup-test2-on-2018-08-03-11-39-48.zip', 'application/x-zip');


#
# TABLE STRUCTURE FOR: tbl_users
#

DROP TABLE IF EXISTS `tbl_users`;

CREATE TABLE `tbl_users` (
  `id_user` int(150) NOT NULL AUTO_INCREMENT,
  `nama_user` varchar(150) NOT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_users` (`id_user`, `nama_user`, `username`, `password`, `created_at`, `updated_at`) VALUES (1, 'Administrator', 'admin', '21232f297a57a5a743894a0e4a801fc3', '2017-02-21 04:14:16', '2017-03-06 13:42:37');


#
# TABLE STRUCTURE FOR: todo
#

DROP TABLE IF EXISTS `todo`;

CREATE TABLE `todo` (
  `tgl` datetime NOT NULL,
  `activity` varchar(255) NOT NULL,
  `status` varchar(10) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`activity`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-08-02 11:00:58', 'backup-test-on-2018-08-02-11-00-58.zip', 'Sukses', 'Berhasil Masuk di DB');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-08-03 11:30:43', 'backup-test-on-2018-08-03-11-30-43.zip', 'Sukses', 'Berhasil Masuk di DB');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-08-03 11:39:48', 'backup-test-on-2018-08-03-11-39-48.zip', 'Sukses', 'Berhasil Masuk di DB');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-08-03 11:30:43', 'backup-test2-on-2018-08-03-11-30-43.zip', 'Sukses', 'Berhasil Masuk di DB');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-08-03 11:39:48', 'backup-test2-on-2018-08-03-11-39-48.zip', 'Sukses', 'Berhasil Masuk di DB');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-08-03 11:40:58', 'Doing Backup on test 2018-08-03-11-40-58', 'Gagal', 'Melakukan Koneksi Ke Database Gagal, Silahkan Cek Konfigurasi Database');


