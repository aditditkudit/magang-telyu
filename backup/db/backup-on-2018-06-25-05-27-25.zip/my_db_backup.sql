#
# TABLE STRUCTURE FOR: tbl_users
#

DROP TABLE IF EXISTS `tbl_users`;

CREATE TABLE `tbl_users` (
  `id_user` int(150) NOT NULL AUTO_INCREMENT,
  `nama_user` varchar(150) NOT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_users` (`id_user`, `nama_user`, `username`, `password`, `created_at`, `updated_at`) VALUES (1, 'Administrator', 'admin', '21232f297a57a5a743894a0e4a801fc3', '2017-02-21 04:14:16', '2017-03-06 13:42:37');


#
# TABLE STRUCTURE FOR: todo
#

DROP TABLE IF EXISTS `todo`;

CREATE TABLE `todo` (
  `tgl` datetime NOT NULL,
  `activity` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`tgl`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-08 09:02:04', 'backup-on-2018-06-08-09-02-04.zip', 'backup/db/', '-');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-08 09:02:14', 'backup-on-2018-06-08-09-02-14.zip', 'backup/db/', '-');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-08 09:21:11', 'backup-on-2018-06-08-09-21-11.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-08 09:21:57', 'backup-on-2018-06-08-09-21-57.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-08 09:23:08', 'backup-on-2018-06-08-09-23-08.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-08 09:35:54', 'backup-on-2018-06-08-09-35-54.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-08 10:03:40', 'backup-on-2018-06-08-10-03-40.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-08 10:04:11', 'backup-on-2018-06-08-10-04-11.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-08 10:07:47', 'backup-on-2018-06-08-10-07-47.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-08 10:48:07', 'backup-on-2018-06-08-10-48-07.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-08 10:58:50', 'backup-on-2018-06-08-10-58-50.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-25 05:04:03', 'backup-on-2018-06-25-05-04-03.zip', 'backup/db/', 'Sukses');


