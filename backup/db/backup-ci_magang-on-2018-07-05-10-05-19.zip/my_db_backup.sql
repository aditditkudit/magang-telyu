#
# TABLE STRUCTURE FOR: list_database
#

DROP TABLE IF EXISTS `list_database`;

CREATE TABLE `list_database` (
  `id_db` int(11) NOT NULL AUTO_INCREMENT,
  `name_database` text NOT NULL,
  PRIMARY KEY (`id_db`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: list_file
#

DROP TABLE IF EXISTS `list_file`;

CREATE TABLE `list_file` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `mime` varchar(255) NOT NULL,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_users
#

DROP TABLE IF EXISTS `tbl_users`;

CREATE TABLE `tbl_users` (
  `id_user` int(150) NOT NULL AUTO_INCREMENT,
  `nama_user` varchar(150) NOT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_users` (`id_user`, `nama_user`, `username`, `password`, `created_at`, `updated_at`) VALUES (1, 'Administrator', 'admin', '21232f297a57a5a743894a0e4a801fc3', '2017-02-21 04:14:16', '2017-03-06 13:42:37');


#
# TABLE STRUCTURE FOR: todo
#

DROP TABLE IF EXISTS `todo`;

CREATE TABLE `todo` (
  `tgl` datetime NOT NULL,
  `activity` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`tgl`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

