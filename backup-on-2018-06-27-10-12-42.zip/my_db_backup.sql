#
# TABLE STRUCTURE FOR: list_file
#

DROP TABLE IF EXISTS `list_file`;

CREATE TABLE `list_file` (
  `datecreate` datetime NOT NULL,
  `filename` varchar(255) NOT NULL,
  `mime` varchar(255) NOT NULL,
  `data` blob NOT NULL,
  PRIMARY KEY (`datecreate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `list_file` (`datecreate`, `filename`, `mime`, `data`) VALUES ('2018-06-27 10:08:50', 'backup-on-2018-06-27-10-08-50.zip', '0', '1');
INSERT INTO `list_file` (`datecreate`, `filename`, `mime`, `data`) VALUES ('2018-06-27 10:10:33', 'backup-on-2018-06-27-10-10-33.zip', '0', '1');
INSERT INTO `list_file` (`datecreate`, `filename`, `mime`, `data`) VALUES ('2018-06-27 10:10:45', 'backup-on-2018-06-27-10-10-45.zip', '0', '1');


#
# TABLE STRUCTURE FOR: tbl_users
#

DROP TABLE IF EXISTS `tbl_users`;

CREATE TABLE `tbl_users` (
  `id_user` int(150) NOT NULL AUTO_INCREMENT,
  `nama_user` varchar(150) NOT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_users` (`id_user`, `nama_user`, `username`, `password`, `created_at`, `updated_at`) VALUES (1, 'Administrator', 'admin', '21232f297a57a5a743894a0e4a801fc3', '2017-02-21 04:14:16', '2017-03-06 13:42:37');


#
# TABLE STRUCTURE FOR: todo
#

DROP TABLE IF EXISTS `todo`;

CREATE TABLE `todo` (
  `tgl` datetime NOT NULL,
  `activity` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`tgl`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-25 11:39:50', 'backup-on-2018-06-25-11-39-50.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-25 11:40:19', 'backup-on-2018-06-25-11-40-19.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-26 08:54:20', 'backup-on-2018-06-26-08-54-20.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-26 08:57:29', 'backup-on-2018-06-26-08-57-29.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-26 09:00:07', 'backup-on-2018-06-26-09-00-07.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-26 10:06:26', 'backup-on-2018-06-26-10-06-26.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-27 10:08:50', 'backup-on-2018-06-27-10-08-50.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-27 10:10:33', 'backup-on-2018-06-27-10-10-33.zip', 'backup/db/', 'Sukses');
INSERT INTO `todo` (`tgl`, `activity`, `status`, `keterangan`) VALUES ('2018-06-27 10:10:45', 'backup-on-2018-06-27-10-10-45.zip', 'backup/db/', 'Sukses');


